// const url = "http://192.168.43.163:4444/api";
const url = process.env.MUSIVE_API_URL;

export default url;
